./disable-app
./disable-tm-reader
