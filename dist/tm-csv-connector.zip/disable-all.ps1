./disable-app
./disable-tm-reader
./disable-barcode-scanner
