./publish-utilities
./edit-env
./set-db-passwords
./initialize-config
./enable-tm-reader
./enable-app
