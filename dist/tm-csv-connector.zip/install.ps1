./publish-utilities
./edit-env
./set-db-passwords
./initialize-config
./enable-tm-reader
./enable-barcode-scanner
./enable-app
