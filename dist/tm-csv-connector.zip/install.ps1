./publish-utilities
./edit-env
./set-db-passwords
./initialize-config
./enable-tm-reader
./enable-barcode-scanner
./enable-trident-reader
./enable-app
