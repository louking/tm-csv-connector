docker compose down
